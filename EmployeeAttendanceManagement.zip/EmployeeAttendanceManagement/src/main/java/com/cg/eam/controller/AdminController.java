package com.cg.eam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.eam.entity.Admin;
import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.repo.EmployeeRepo;
import com.cg.eam.service.AdminService;
import com.cg.eam.service.AdminStaffService;

/**
 * @author hgupta4
 *
 */
//@CrossOrigin("http://localhost:4200")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class AdminController {
	@Autowired
	private AdminService service;

	@Autowired
	private AdminStaffService staffService;

	@Autowired
	private EmployeeRepo empCrud;
	/**
	 * @return adminLogin method of AdminStaffService
	 */
	@GetMapping(path = "/login", produces = "application/json")
	public List<Admin> getAdmin() {
		return service.adminLogin();

	}

	/**
	 * @return employeeList method of AdminStaffService
	 */
//	@GetMapping("/getall")
//	public List<Employee> employeeList() {
//		return service.employeeList();
//	}
	@GetMapping("/getall")
	public Page<Employee> employeeList(@RequestParam(defaultValue = "0")int page) {
		 PageRequest pageable=PageRequest.of(page, 5,Sort.by("name"));
	     return empCrud.findAll(pageable);
 //		return service.employeeList();
	}

	/**
	 * @param Object e of Employee entity
	 * @return addEmployee method of AdminStaffService
	 */
	@PostMapping("/add")
	public Employee addEmployee(@RequestBody Employee e) {
		return service.addEmployee(e);

	}

	/**
	 * @param id of the Employee entity
	 * @return employeeDetails method of AdminStaffService
	 */
	@GetMapping("/getById/{id}")
	public Employee employeeDetails(@PathVariable int id) {
		return service.employeeDetails(id);
	}

	/**
	 * @param id of the Employee entity
	 * @return deleteEmployee method of AdminStaffService
	 */
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		return service.deleteEmployee(id);

	}

	/**
	 * @param Object a of Attendance entity
	 * @return updateEmployeeAttendance method of AdminStaffService
	 */
	@PutMapping("/updateAttendance")
	public String updateEmployeeAttendance(@RequestBody Attendance a) {
		return staffService.updateEmployeeAttendance(a);

	}
}
