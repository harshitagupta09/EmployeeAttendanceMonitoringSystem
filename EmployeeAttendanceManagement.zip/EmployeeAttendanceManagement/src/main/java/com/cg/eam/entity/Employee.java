package com.cg.eam.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	@GeneratedValue
	private int id;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private String mobileNo;
	@Column(nullable = false)
	private int salary;
	private int lop;
	@Column(nullable = false)
	private String userName;
	@Column(nullable = false)
	private String password;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}



	public int getLop() {
		return lop;
	}

	public void setLop(int lop) {
		this.lop = lop;
	}
	
	public Employee() {
		super();
		
	}
	

	public Employee(int id, String name, String mobileNo, int salary, int lop) {
		super();
		this.id = id;
		this.name = name;
		this.mobileNo = mobileNo;
		this.salary = salary;
		this.lop = lop;
	}

}
