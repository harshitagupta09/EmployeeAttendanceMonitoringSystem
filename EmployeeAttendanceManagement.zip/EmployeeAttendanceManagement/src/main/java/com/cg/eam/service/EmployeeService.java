package com.cg.eam.service;

import java.util.List;

import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.entity.Login;

public interface EmployeeService {

	/**
	 * @param login
	 */
	public Employee employeeLogin(Login login);

	/**
	 * @param id
     * @return attendance of the employee 
	 */
	public List<Attendance> viewEmployeeAttendance(int id);

	/**
	 * @param id
	 * @return lop
	 */
	public int viewLop(int id);

	/**
	 * @param employeeId
	 * @param date
	 */
	public String applyForLeave(int employeeId, String date);

}
