package com.cg.eam.repo;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.eam.entity.Admin;

/**
 * @author hgupta4
 *
 */
public interface AdminRepo extends JpaRepository<Admin, Integer> {

	
	/**
	 * @param username of the admin
	 * @param password for admin login
	 * @return Admin
	 */
	public Optional<Admin> findByUserNameAndPassword(String userName, String password);

}
