package com.cg.eam.service;

import com.cg.eam.entity.Attendance;

public interface AdminStaffService {

	/**
	 * @param attendance
	 * @return "updated"  
	 */
	public String updateEmployeeAttendance(Attendance attendance);

	/**
	 * @param id
	 * @return lop
	 */
	public int calculateLop(int id);

}
