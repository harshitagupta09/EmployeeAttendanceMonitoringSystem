package com.cg.eam.service;

import java.util.List;
import com.cg.eam.entity.Admin;
import com.cg.eam.entity.Employee;

public interface AdminService {

	
	public List<Admin> adminLogin();

	
	public List<Employee> employeeList();

	/**
	 * @param e
	 */
	public Employee addEmployee(Employee e);

	/**
	 * @param id
	 */
	public Employee employeeDetails(int id);

	/**
	 * @param id
	 */
	public String deleteEmployee(int id);

	/**
	 * @param id
	 */
	public String login(int id);

}
