package com.cg.eam.repo;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.eam.entity.Employee;

/**
 * @author hgupta4
 *
 */
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	
	/**
	 * @param username of employee
	 * @param password for employee login
	 * @return Employee
	 */
	public Optional<Employee> findByUserNameAndPassword(String userName,String password);
}
