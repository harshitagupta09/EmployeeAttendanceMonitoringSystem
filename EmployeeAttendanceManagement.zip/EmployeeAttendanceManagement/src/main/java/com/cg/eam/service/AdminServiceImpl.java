package com.cg.eam.service;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.eam.entity.Admin;
import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.repo.AdminRepo;
import com.cg.eam.repo.EmployeeRepo;

/**
 * @author hgupta4
 *
 */
@Service
@Transactional
public class AdminServiceImpl implements AdminService {
	@Autowired
	private EmployeeRepo repo;

	@Autowired
	private AdminRepo adminRepo;

	@Autowired
	AdminStaffService adminStaffService;

	@Override
	public List<Admin> adminLogin() {
		List<Admin> list = adminRepo.findAll();
		return list;
	}

	@Override
	public List<Employee> employeeList() {

		return repo.findAll();
	}

	@Override
	public Employee addEmployee(Employee e) {

		Optional<Employee> res = repo.findById(e.getId());
		if (!res.isPresent()) {
			e.setPassword(e.getUserName() + "123");
			repo.save(e);
			return e;
		}
		System.out.println(res);

		return null;

	}

	@Override
	public Employee employeeDetails(int id) {

		return repo.findById(id).get();
	}

	@Override
	public String deleteEmployee(int id) {

		repo.deleteById(id);
		return " Deleted";

	}

	@Override
	public String login(int id) {
		Date date = new Date();
		System.out.println(date);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String formattedDate = formatter.format(date);
		System.out.println(formattedDate);
		if (repo.findById(id).isPresent()) {
			Attendance attendance = new Attendance();
			attendance.setDate(formattedDate);
			attendance.setStatus("Present");
			attendance.setEmpId(id);
			adminStaffService.updateEmployeeAttendance(attendance);
			return "Present";
		} else
			return "Not Present";
	}

}
