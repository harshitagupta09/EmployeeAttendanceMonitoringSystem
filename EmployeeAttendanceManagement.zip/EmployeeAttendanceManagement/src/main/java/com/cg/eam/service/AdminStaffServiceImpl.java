package com.cg.eam.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.repo.AttendanceRepo;
import com.cg.eam.repo.EmployeeRepo;

@Service
@Transactional
public class AdminStaffServiceImpl implements AdminStaffService {
	@Autowired
	private AttendanceRepo repo;

	@Autowired
	private EmployeeRepo empRepo;

	@Override
	public String updateEmployeeAttendance(Attendance attendance) {

		if (repo.findByDateAndEmpId(attendance.getDate(), attendance.getEmpId()).isPresent()) {
			System.out.println("Already came");
		} else {
			repo.save(attendance);
			System.out.println("saved");
		}
		return "Updated";
	}

	@Override
	public int calculateLop(int id) {

		int countOfLeavesApplied = (repo.findByEmpIdAndStatus(id, "Leave").size());
		Optional<Employee> e = empRepo.findById(id);
		int oneDaySalary = (e.get().getSalary() / 30);
		int LOP = (oneDaySalary * countOfLeavesApplied);
		e.get().setLop(LOP);
		return LOP;
	}

}
