package com.cg.eam.repo;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.eam.entity.Attendance;

/**
 * @author hgupta4
 *
 */
public interface AttendanceRepo extends JpaRepository<Attendance, Integer> {

	/**
	 * @param id
	 * @return Attendance
	 */
	public List<Attendance> findByEmpId(int id);

	
	/**
	 * @param date
	 * @param id
	 * @return Attendance
	 */
	public Optional<Attendance> findByDateAndEmpId(String date, int id);

	
	/**
	 * @param id
	 * @param status
	 * @return Attendance
	 */
	public List<Attendance> findByEmpIdAndStatus(int id, String status);

}
